package com.redwine.vanshika

import android.content.Context
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import androidx.lifecycle.ViewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.NavType
import androidx.navigation.compose.navArgument
import android.content.SharedPreferences
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import com.redwine.vanshika.R

class MainActivity : ComponentActivity() {

    private val vm by viewModels<PhotosViewModel>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pickImages = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
            if (uris != null) vm.addAll(uris)
        }

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFFD50000),
                    onPrimary = Color.White,
                    background = Color(0xFF000000),
                    onBackground = Color.White,
                    surface = Color(0xFF121212),
                    onSurface = Color.White,
                    secondary = Color(0xFFE53935)
                )
            ) {
                val nav = rememberNavController()
                NavHost(navController = nav, startDestination = "lock") {
                    composable("lock") {
                        LockScreen(
                            onUnlocked = { nav.navigate("home") { popUpTo("lock") { inclusive = true } } },
                            context = this@MainActivity
                        )
                    }
                    composable("home") {
                        HomeScreen(
                            vm = vm,
                            onPick = { pickImages.launch("image/*") },
                            onOpenViewer = { index -> nav.navigate("viewer/$index") },
                            nav = nav,
                            context = this@MainActivity
                        )
                    }
                    composable(
                        "viewer/{index}",
                        arguments = listOf(navArgument("index") { type = NavType.IntType })
                    ) { backStackEntry ->
                        val startIndex = backStackEntry.arguments?.getInt("index") ?: 0
                        ViewerScreen(vm = vm, startIndex = startIndex, context = this@MainActivity)
                    }
                    composable("settings") {
                        SettingsScreen(context = this@MainActivity, onBack = { nav.popBackStack() })
                    }
                }
            }
        }
    }
}

class PhotosViewModel : ViewModel() {
    private val _photos = mutableStateListOf<Uri>()
    val photos: List<Uri> get() = _photos

    fun addAll(list: List<Uri>) {
        _photos.addAll(list)
    }
}

@Composable
fun LockScreen(onUnlocked: () -> Unit, context: Context) {
    val prefs = context.getSharedPreferences("rw_prefs", Context.MODE_PRIVATE)
    val correct = prefs.getString("secret", "RedWine") ?: "RedWine"
    var input by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }

    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFFD50000)) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(imageVector = ImageVector.vectorResource(id = R.drawable.ic_heart), contentDescription = null, tint = Color.White,
                modifier = Modifier.size(72.dp))
            Spacer(Modifier.height(16.dp))
            Text(
                text = "Red Wine — Vanshika",
                style = MaterialTheme.typography.titleLarge,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = "Enter secret:",
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = input,
                onValueChange = { input = it; error = false },
                label = { Text("Type secret", color = Color.White) },
                isError = error,
                singleLine = true
            )
            Spacer(Modifier.height(12.dp))
            Button(onClick = {
                if (input == correct) onUnlocked() else error = true
            }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB00020))) {
                Text("Unlock", color = Color.White)
            }
            if (error) {
                Spacer(Modifier.height(8.dp))
                Text("Wrong secret 💔", color = Color.White)
            }
        }
    }
}

@Composable
fun HomeScreen(vm: PhotosViewModel, onPick: () -> Unit, onOpenViewer: (Int) -> Unit, nav: androidx.navigation.NavHostController, context: Context) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Red Wine • Vanshika", color = MaterialTheme.colorScheme.onPrimary) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primary),
                actions = {
                    TextButton(onClick = { nav.navigate("settings") }) {
                        Text("Settings", color = MaterialTheme.colorScheme.onPrimary)
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = onPick, containerColor = MaterialTheme.colorScheme.primary) {
                Text("Add Photos", color = MaterialTheme.colorScheme.onPrimary)
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            PraiseCard()
            Spacer(Modifier.height(16.dp))
            if (vm.photos.isEmpty()) {
                Text(
                    text = "Add Vanshika's beautiful photos — tap the red button below 💖",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                    textAlign = TextAlign.Center
                )
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(minSize = 120.dp),
                    modifier = Modifier.fillMaxSize(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(vm.photos) { index, uri ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .clickable { onOpenViewer(index) },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            AsyncImage(model = uri, contentDescription = "Vanshika", modifier = Modifier.fillMaxSize())
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PraiseCard() {
    // Using a bundled font if present
    val romantic = try {
        FontFamily(Font(R.font.romantic))
    } catch (e: Exception) {
        FontFamily.Default
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Red Wine — Vanshika",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimary,
                fontFamily = romantic
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Vanshika, tum meri Red Wine ho — classy, strong, aur har din aur khoobsurat. Tumhari muskaan se din shuru ho, aur tumhari yaadon pe raat khatam. 💌",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onPrimary
            )
        }
    }
}

@Composable
fun ViewerScreen(vm: PhotosViewModel, startIndex: Int, context: Context) {
    val pagerState = rememberPagerState(initialPage = startIndex, pageCount = { vm.photos.size })
    var playing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var mediaPlayer: MediaPlayer? = remember { null }
    val prefs = context.getSharedPreferences("rw_prefs", Context.MODE_PRIVATE)
    val musicEnabled = prefs.getBoolean("music", True)

    DisposableEffect(playing) {
        if (playing && musicEnabled) {
            try {
                mediaPlayer = MediaPlayer.create(context, R.raw.slideshow_music)
                mediaPlayer?.isLooping = true
                mediaPlayer?.start()
            } catch (e: Exception) {
                // ignore if missing
            }
        } else {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
        }
        onDispose {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        }
    }

    LaunchedEffect(playing) {
        while (playing && vm.photos.isNotEmpty()) {
            delay(2000)
            val next = (pagerState.currentPage + 1) % vm.photos.size
            scope.launch { pagerState.animateScrollToPage(next) }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Slideshow", color = MaterialTheme.colorScheme.onPrimary) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primary),
                actions = {
                    TextButton(onClick = { /* nothing */ }) {
                        Text(if (playing) "Pause" else "Play", color = MaterialTheme.colorScheme.onPrimary)
                    }
                }
            )
        }
    ) { padding ->
        Box(modifier = Modifier
            .padding(padding)
            .fillMaxSize()) {
            if (vm.photos.isNotEmpty()) {
                HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize()) { page ->
                    AsyncImage(model = vm.photos[page], contentDescription = "Photo $page", modifier = Modifier.fillMaxSize())
                }
                FloatingActionButton(onClick = { playing = !playing }, modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)) {
                    Text(if (playing) "❚❚" else "▶")
                }
            } else {
                Text("No photos selected.", modifier = Modifier.align(Alignment.Center))
            }
        }
    }
}

@Composable
fun SettingsScreen(context: Context, onBack: () -> Unit) {
    val prefs = context.getSharedPreferences("rw_prefs", Context.MODE_PRIVATE)
    var secret by remember { mutableStateOf(prefs.getString("secret", "RedWine") ?: "RedWine") }
    var music by remember { mutableStateOf(prefs.getBoolean("music", True)) }

    Scaffold(topBar = {
        TopAppBar(title = { Text("Settings") }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFFD50000)), navigationIcon = {
            TextButton(onClick = onBack) { Text("Back", color = Color.White) }
        })
    }) { padding ->
        Column(modifier = Modifier.padding(padding).padding(16.dp)) {
            OutlinedTextField(value = secret, onValueChange = { secret = it }, label = { Text("Secret phrase") })
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Slideshow music")
                Spacer(Modifier.width(8.dp))
                Switch(checked = music, onCheckedChange = { music = it })
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = {
                prefs.edit().putString("secret", secret).putBoolean("music", music).apply()
                onBack()
            }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB00020))) {
                Text("Save", color = Color.White)
            }
        }
    }
}
